package com.isep.testjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestjpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestjpaApplication.class, args);
    }


}
