package com.isep.testjpa.controller;

import org.springframework.web.bind.annotation.*;
import com.isep.testjpa.model.Emp;
import com.isep.testjpa.repository.EmpRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;


@RestController
public class SimpleController {

    @Autowired
    private EmpRepository empRepository;


    @RequestMapping(value="/", method= RequestMethod.GET)
    public String hello(@RequestParam(value = "name", required = false) String name) {
        return "Hello " + name;
    }

    @RequestMapping(value="/employees", method= RequestMethod.GET)
    public List<Emp> getEmployees() {
        return empRepository.findAll();
    }

    @PostMapping(value="/emp/add")
    public Emp addEmployee(@RequestBody Emp emp) {
        return empRepository.save(emp);
    }

    @RequestMapping(value="/emp/retrieve", method= RequestMethod.GET)
    public Optional<Emp> getEmp(@RequestParam(value = "empid", required = true) String empid) {
        return empRepository.findById(Long.parseLong(empid));
    }

    @PostMapping(value="/emp/delete")
    public void delete(@RequestParam(value = "empid", required = true) String empid) {
        empRepository.deleteById(Long.parseLong(empid));
    }

}
